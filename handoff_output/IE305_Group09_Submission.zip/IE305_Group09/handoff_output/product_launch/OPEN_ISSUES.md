# Open issues, ranked by evaluation importance

| Priority | Issue | What resolves it / how to present honestly |
|---|---|---|
|1 — required submission and live demo|Preserve the successful revised model and actual exports|Default import/compile/run/animation/export succeeded. Screenshot and CSV comparison are saved. Bring that exact model to the presentation; broader engine-batch evidence is still pending|
|2 — submission logistics|The announcement says submit before 3 November 16:00 IST|The students must check the actual Moodle status or any extension and submit the `.alp`, support files and slides. A prepared folder is not an uploaded submission|
|3 — live presentation|Rehearse the required 13 minutes including the model demonstration|Use the speaker timings, split speaking roles and keep the live demonstration short. Bring the saved model, local files and a screenshot fallback. Attend the whole Group 9 slot on 4 November, 14:00–15:40, LC002|
|4 — engine evidence breadth|Large numerical results currently come from the reference implementation|After the first engine run succeeds, collect a small matched AnyLogic batch if feasible. Label actual engine run counts separately; do not relabel the full Python/C++ grid as AnyLogic output|
|5 — model validity|Purchase and contact rules are synthetic, uncalibrated assumptions|State this upfront. Discuss sensitivity; do not claim real demand, real optimal price or evidence that actual students behave this way|
|6 — surprising quality response|Hard bounded confidence can prevent very positive owners from influencing moderate nonowners|Report the controlled diagnostic. It is a warning about applying an opinion mechanism to product decisions, not a recommendation to lower actual quality. Future work would calibrate or soften the confidence rule|
|7 — coverage of sample quantities|Only 3 and 12 samples are tested, not every possible quantity|Call the recommendation best among tested choices. Zero samples implies no initial awareness in this model and thus no launch; other advertising channels are absent. An interior/global optimum has not been found|
|8 — practical targeting expense|Degree information and group membership are assumed available at no additional cost|The modest incremental targeting gain may not justify acquiring network data. Add actual targeting cost before making a business decision|
|9 — recommendation and targeting comparisons|Several pointwise intervals were examined|Do not claim equivalence when an interval includes zero. Do not present one exploratory h effect as a universal platform rule|
|10 — omitted operations|Inventory, delivery, returns, competition, fixed overhead and repeat purchases are outside scope|Profit is modeled contribution after production/sample costs. It is not a complete profit-and-loss statement. Keep the one-product campaign scope explicit|
|11 — literature extraction limits|Some original PDFs have garbled formulas; Bass and DiMaggio readable full text remain unavailable|Keep the parent read-status table and `[UNVERIFIED]` markers. A readable authorized PDF/OCR would resolve these gaps. Do not cite unread equations as verified|
|12 — precise literature critical points|KB and binary-voter finite-size thresholds were not exactly reproduced|Parent validation report labels these partial. Published critical values are not automatically targets for the product extension|
|13 — PowerPoint rendering|OOXML package/relationships can be checked here; Windows PowerPoint rendering needs a local look|Use the generated editable deck and its HTML fallback. Check layout once on the presenting computer; do not infer visual compatibility solely from XML validity|
|14 — remote synchronization|The user is uploading/pushing manually|Ensure the final files reach the remote and pull/download those exact files on the presentation computer. Local preparation does not prove a remote upload|

Do not add untested features to address every limitation before the presentation. Prioritize a working required model, traceable analysis, a clear explanation and honest boundaries.

## New live-network variant

The user requested it after approving the grid version. It is a separate file, with real API and181-case default/batch wiring checks passing. Actual editor import, animation/performance and engine export for that variant remain pending. Use the engine-tested grid as the fallback. The latest live-network guide defines line styles, ownership rings, opinion colors and the extra disjoint customer-state metrics.

The portable primary deck now passes independent Apache POI/XmlBeans schema validation and has Java2D previews. It uses standard rendered plots; the separate native-chart deck retains editable workbooks. The local schema library was incomplete for one native-chart type, so no full native-chart schema-validation claim is made.

Actual CSVs from the earlier live-network default have now been checked: the summary matches Java, all61 extra metric rows satisfy the partitions, and the same replication is not counted as an independent new market. The final white-layout visual check remains separate.

For the remaining full-text extraction gaps, please attach readable authorized PDFs/OCR of Deffuant's unrecovered mathematics, DiMaggio1996, Bass1969 and the missing Delre2010 segment if those checks are to be completed. The current presentation does not rely on their unverified equations or an unread empirical trend claim.
